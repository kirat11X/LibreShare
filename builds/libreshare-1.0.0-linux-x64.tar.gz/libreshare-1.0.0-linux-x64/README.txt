LibreShare 1.0.0 (prototype) - Linux x64
Run:  ./libreshare_app            (add --hidden to start in the tray)
Needs: GTK 3 (libgtk-3-0), libstdc++, glibc 2.31+; a tray needs an AppIndicator host
(GNOME: the "AppIndicator and KStatusNotifierItem Support" extension).
Firewall: allow UDP 53318 (discovery) and TCP 53317-53349 (transfers) on your private network.
Prototype: no encryption yet (Increment 3 adds it). Only use on a network you trust.
